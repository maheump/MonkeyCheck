function SuperposeSequence( s, point_size )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

lim = get(gca, 'ylim');

load('PlotParam.mat');
Stimcol = PlotParam.Stimcol;
if nargin < 2, point_size = 5; end

gcf; hold on;
plot(find(s==1), lim(2), 'o', 'MarkerEdgeColor', Stimcol(1,:), ...
                                 'MarkerFaceColor', Stimcol(1,:), ...
                                 'MarkerSize',      point_size); hold on;
plot(find(s==2), lim(1), 'o', 'MarkerEdgeColor', Stimcol(2,:), ...
                                 'MarkerFaceColor', Stimcol(2,:), ...
                                 'MarkerSize',      point_size); hold on;
 
ylim(lim);

end