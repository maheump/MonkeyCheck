function [ Bstim, L, pA, Nblocks, trials ] = BernoullianSeqStim( L, EventProba, symblc )

%BERNOULLIANSEQSTIM Create sequence of stimuli of length L according to
%events probabilities specified in EventProba.
% 
%   L = 380;
%
%   TransitionProba = ... %    P(A)
%                         [    0.30     , ... % Block 1
%                              0.50     , ... % Block 2
%                              0.70     ];    % Block 3

% Initialize random generators
try
    s = RandStream('mt19937ar', 'Seed', 'shuffle');
    RandStream.setGlobalStream(s);
catch
    rand('twister', sum(100*clock));
end

% Choose to use symbolic function or not
if nargin < 3, symblc = 0; end

% Number of blocks
Nblocks = size(EventProba, 2);

% For each block (different parameters)
for block = 1:Nblocks
    
    % Proportion of A
    pA(block) = EventProba(block);
    
    % SIMULATE BERNOULLI SEQUENCE
	seq = rand(1, L);
	seq = seq(randperm(L));
    RndGen = seq - pA(block);
    if symblc
        s = heaviside(RndGen) + 1;
    else
        s = (RndGen > 0) + 1;
    end
    
    % And return it
    Bstim(block, :) = s; % A or B
    trials(block, :) = (1:L) + (L * (block - 1)); % Trial numbers

end

% Final sequence length
L = size(Bstim, 1)*size(Bstim, 2);
            
end